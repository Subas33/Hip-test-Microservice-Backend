package com.bsh.hip.sample.s3.provider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.util.UUID;


import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.apache.http.entity.ContentType;
import org.springframework.mock.web.MockMultipartFile;
import com.bsh.hip.sample.s3.model.Response;
import com.bsh.hip.sample.s3.model.User;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class S3DataProvider {

	public User fetchAllData() {
		User userinput = new User();
		userinput.setFirstName("Subash");
		userinput.setLastName("Muthumanickam");
		userinput.setRequestid("872681726hd");
		userinput.setOrganization("BSH");
		userinput.setRole("Developer");
		return userinput;
	}


	public String generateRequestId(String requestId) {
		if (requestId == null) {
			return UUID.randomUUID().toString();
		} else {
			return requestId;
		}
	}

	public User readFile(String filename) {

		try {
			ObjectMapper mapper = new ObjectMapper();
			InputStream input = new FileInputStream(
					new File("C:\\Users\\extMuthumanickam\\Documents\\Hip-Task\\Task_1\\Files\\"+filename+".json"));
			TypeReference<User> type = new TypeReference<User>() {
			};
			User user = mapper.readValue(input, type);
			input.close();
			return user;

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;

	}
	
	
	public User writeFile(User userinput) throws JsonGenerationException, IOException {
		

		ObjectMapper mapper = new ObjectMapper();
		String filename = userinput.getRequestid();
			try {
				mapper.writeValue(new File("C:\\Users\\extMuthumanickam\\Documents\\Hip-Task\\Task_1\\Files\\"+filename+".json"), userinput);
				
			} 
			catch (JsonMappingException e) {
				e.printStackTrace();
			}
			return readFile(filename);
		
	}
	
	public MultipartFile setFile(User userinput) throws JsonGenerationException, IOException {
		
		String fileName = userinput.getRequestid();
		
		ObjectMapper mapper = new ObjectMapper();
			try {
				mapper.writeValue(new File("C:\\Users\\extMuthumanickam\\Documents\\Hip-Task\\Task_1\\Files\\"+fileName+".json"), userinput);
				
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} 
		return getFile(fileName);
		
	}
	
	public MultipartFile getFile(String fileName) throws FileNotFoundException {
		
		File file = new File("C:\\Users\\extMuthumanickam\\Documents\\Hip-Task\\Task_1\\Files\\"+fileName+".json");
		FileInputStream fileInputStream = new FileInputStream(file);
		try {
			MultipartFile multipartFile = new MockMultipartFile(file.getName(),file.getName(),ContentType.APPLICATION_OCTET_STREAM.toString(),fileInputStream);
			return multipartFile;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return null;

	}
	
	
	
	public String generateFileName(MultipartFile file) {
		return file.getOriginalFilename();
	}
	
	public File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(generateFileName(file));
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

	public Response response(String url,String bucketName, String fileName, String status) {
		return new Response(url,bucketName,fileName,status);
	}
}
