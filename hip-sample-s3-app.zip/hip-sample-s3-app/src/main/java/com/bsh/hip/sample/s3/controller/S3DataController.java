package com.bsh.hip.sample.s3.controller;

import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.bsh.hip.sample.s3.model.Response;
import com.bsh.hip.sample.s3.model.User;
import com.bsh.hip.sample.s3.service.AmazonClient;
import com.bsh.hip.sample.s3.service.S3Service;
import com.fasterxml.jackson.core.JsonGenerationException;

@RestController
@RequestMapping(path = "/s3")
public class S3DataController {

	@Autowired
	private AmazonClient amazonClient;

	@Autowired
	private S3Service s3Service;

	@GetMapping(path = "/user")
	public User getUser(@RequestParam(required = false) String requestId) {
		return s3Service.getData(requestId);
	}

	@PostMapping(path = "/user")
	public ResponseEntity<User> pushOneUserData(@RequestBody User user) throws JsonGenerationException, IOException {
		return new ResponseEntity<User>(s3Service.writeData(user), HttpStatus.ACCEPTED);

	}

	@PostMapping(path = "/users/upload/data")
	public ResponseEntity<Response> uploaddata( @RequestBody User user)
			throws IOException {
		MultipartFile file = s3Service.setFile(user);
		return amazonClient.uploadFile(file);
	}
	
	@PostMapping(path = "/users/upload/file")
	public ResponseEntity<Response> uploadFile(@RequestPart MultipartFile file )
			throws IOException {
			return this.amazonClient.uploadFile(file);
	}

	@GetMapping(path = "/users/download/{filename}")
	public ResponseEntity<ByteArrayResource> downloadFile(@PathVariable String filename) {
		byte[] data = amazonClient.downloadFileFromS3(filename);
		ByteArrayResource file = new ByteArrayResource(data);
		return ResponseEntity.ok().contentLength(data.length).header("Content-type", "application/octet-stream")
				.header("Content-disposition", "attachment; filename=\"" + filename + "\"").body(file);
	}

}
