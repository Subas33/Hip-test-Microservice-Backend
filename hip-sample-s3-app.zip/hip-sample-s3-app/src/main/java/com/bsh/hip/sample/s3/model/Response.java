package com.bsh.hip.sample.s3.model;

public class Response {
	
	
	private String url;
	
	private String bucketName;
	
	private String fileName;
	
	private String status;
	
	

	public Response() {
		
	}



	public Response(String url, String bucketName, String fileName, String status) {
		super();
		this.url = url;
		this.bucketName = bucketName;
		this.fileName = fileName;
		this.status = status;
	}



	public String getUrl() {
		return url;
	}



	public void setUrl(String url) {
		this.url = url;
	}



	public String getBucketName() {
		return bucketName;
	}



	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}



	public String getFileName() {
		return fileName;
	}



	public void setFileName(String fileName) {
		this.fileName = fileName;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
