package com.bsh.hip.sample.s3.exception;

public class ResourceAlreadyExistException extends RuntimeException{
	
	private static final long serialVersionUID = -2147399048316632648L;

	public ResourceAlreadyExistException(String message) {
		super(message);
	}

}
