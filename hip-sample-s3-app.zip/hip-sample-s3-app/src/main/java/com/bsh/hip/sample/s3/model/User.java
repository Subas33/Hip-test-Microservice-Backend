package com.bsh.hip.sample.s3.model;

public class User {

	
	private String requestid;

	private String firstName;

	private String lastName;

	private String organization;

	private String role;

	

	public User() {

	}



	public User(String requestid, String firstName, String lastName, String organization, String role) {
		super();
		this.requestid = requestid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.organization = organization;
		this.role = role;
	}



	public String getRequestid() {
		return requestid;
	}



	public void setRequestid(String requestid) {
		this.requestid = requestid;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getOrganization() {
		return organization;
	}



	public void setOrganization(String organization) {
		this.organization = organization;
	}



	public String getRole() {
		return role;
	}



	public void setRole(String role) {
		this.role = role;
	}

	
	
}
