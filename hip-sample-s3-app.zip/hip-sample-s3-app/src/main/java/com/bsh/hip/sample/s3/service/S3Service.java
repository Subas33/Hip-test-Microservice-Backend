package com.bsh.hip.sample.s3.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.bsh.hip.sample.s3.model.User;
import com.bsh.hip.sample.s3.provider.S3DataProvider;
import com.fasterxml.jackson.core.JsonGenerationException;

@Service
public class S3Service {
	
	@Autowired
	private S3DataProvider s3Provider;

	public User getallData(String requestId) {
		return s3Provider.readFile(requestId);
	}
	
	public User getData(String requestId) {
		String generatedRequestId = s3Provider.generateRequestId(requestId);
		return s3Provider.readFile(generatedRequestId);
	}
	
	public User writeData(User user) throws JsonGenerationException, IOException {
		String generatedRequestId = s3Provider.generateRequestId(user.getRequestid());
		user.setRequestid(generatedRequestId);
		return s3Provider.writeFile(user);
	}
	
	public MultipartFile setFile(User userinput) throws JsonGenerationException, IOException {
		String generatedRequestId = s3Provider.generateRequestId(userinput.getRequestid());
		userinput.setRequestid(generatedRequestId);
		return s3Provider.setFile(userinput);
	}
	
}
