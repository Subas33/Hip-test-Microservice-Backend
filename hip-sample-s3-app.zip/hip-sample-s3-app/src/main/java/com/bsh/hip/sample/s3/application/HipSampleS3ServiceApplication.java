package com.bsh.hip.sample.s3.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@ComponentScan(basePackages = "com.bsh.hip.sample.s3.*")
@SpringBootApplication
public class HipSampleS3ServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HipSampleS3ServiceApplication.class, args);
	}

}
