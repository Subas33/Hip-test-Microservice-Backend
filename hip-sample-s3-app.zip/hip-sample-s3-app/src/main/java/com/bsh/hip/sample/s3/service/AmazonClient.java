package com.bsh.hip.sample.s3.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import com.bsh.hip.sample.s3.model.Response;
import com.bsh.hip.sample.s3.provider.S3DataProvider;

@Service
public class AmazonClient {

	@Autowired
	private S3DataProvider provider;

	@Autowired
	private AmazonS3 s3client;

	private String Url = "https://s3.console.aws.amazon.com/s3/object/";
	private String region = "/region=eu-central-1&";
	private String prefix = "prefix=";
	private String bucketName = "sample-s3-rest-integration-bucket";


	public ResponseEntity<Response> uploadFile(MultipartFile multipartFile) throws IOException {

		String fileUrl = "";
		try {
			File file = provider.convertMultiPartToFile(multipartFile);
			String fileName = provider.generateFileName(multipartFile);
			fileUrl = Url + bucketName + "?" + region + prefix + fileName;
			uploadFileTos3bucket(fileName, file);
			file.delete();

			return new ResponseEntity<Response>(provider.response(fileUrl, bucketName, provider.generateFileName(multipartFile), "Upload Success"),HttpStatus.OK);
		}

		catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Response>(provider.response(fileUrl, bucketName, provider.generateFileName(multipartFile), "Upload Failed"),HttpStatus.NOT_IMPLEMENTED);
		}

	}

	private void uploadFileTos3bucket(String fileName, File file) {
		s3client.putObject(new PutObjectRequest(bucketName, fileName, file));
	}

	public byte[] downloadFileFromS3(String fileName) {
		S3Object s3Object = s3client.getObject(bucketName, fileName);
		S3ObjectInputStream input = s3Object.getObjectContent();
		
		try {
			byte[] downloadedFile = IOUtils.toByteArray(input);
			return downloadedFile;
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
