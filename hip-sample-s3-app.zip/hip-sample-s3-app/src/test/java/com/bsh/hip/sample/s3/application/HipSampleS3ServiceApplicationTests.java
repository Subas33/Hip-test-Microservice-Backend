package com.bsh.hip.sample.s3.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HipSampleS3ServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
